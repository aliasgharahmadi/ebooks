The Way to Go: A Thorough Introduction to the Go Programming Language
by Ivo Balbaert

Book web site: <https://sites.google.com/site/thewaytogo2012/>
