// even.go
package even

func Even(i int) bool {		// exported function
	return i%2 == 0
}
