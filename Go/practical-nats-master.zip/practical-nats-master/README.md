# Practical NATS

![alt text](https://images.springer.com/sgw/books/medium/9781484235690.jpg "Practical NATS")

Practical NATS
Source Code

[The Book](https://www.apress.com/us/book/9781484235690)
