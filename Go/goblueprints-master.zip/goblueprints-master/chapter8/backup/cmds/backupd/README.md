
Example:

  ./backupd -interval=10 -archive=./archive -db="./db"

Add paths:

  ./backup -db=../backupd/db add ../test/hash1 ../test/hash2