package defaultmodule

func init() {}
